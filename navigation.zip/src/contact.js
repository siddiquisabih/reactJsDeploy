
import React,{Component} from 'react';





export default class Contact extends React.Component{
    


    render(){
        return (
            <div>countact</div>
        )
    }
}
